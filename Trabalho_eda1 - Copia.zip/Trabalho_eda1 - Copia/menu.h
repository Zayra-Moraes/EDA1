


#ifndef menu_h
#define menu_h

int menuPrincipal();

#endif