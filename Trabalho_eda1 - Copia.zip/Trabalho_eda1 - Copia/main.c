#include <stdio.h>
#include <stdlib.h>
#include "menu.h"


int main()
{
    menuPrincipal();
    return 0;
}